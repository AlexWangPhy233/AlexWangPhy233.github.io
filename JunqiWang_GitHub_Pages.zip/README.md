# Junqi Wang — GitHub Pages

1. 解压后，将 index.html、style.css、assets 文件夹及 .nojekyll 上传到 AlexWangPhy233.github.io 仓库根目录。不要上传 ZIP 本身。
2. Settings → Pages → Deploy from a branch → main → / (root) → Save。
3. 先确认 https://alexwangphy233.github.io/ 正常显示。
4. 在 Pages 的 Custom domain 填入 www.jwangphy.com 并保存，再配置 Namecheap DNS。GitHub 会为分支发布生成 CNAME 文件，之后更新时请保留。
5. 证书就绪后开启 Enforce HTTPS。

首页内容：index.html；排版：style.css；图片：assets/。无需安装依赖或运行构建命令。
本导出包含 GitHub 链接，未列出 In preparation 文章；Notes 保持待添加状态。
.nojekyll 是隐藏空文件；Mac Finder 可按 Command+Shift+. 显示。
